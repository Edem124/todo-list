<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Task;
use Illuminate\View\View;

class TaskController extends Controller
{
    public function index()
    {
        $tasks = auth()->user()->tasks; // Récupérer les tâches de l'utilisateur connecté
        return view('tasks.index', compact('tasks'));
    }

    public function addTask(Request $request)
    {
        $validatedData = $request->validate([
            'task_name' => 'required|max:255',
            
        ]);

        auth()->user()->tasks()->create([
            'name' => $validatedData['task_name'],
            'created_at' => now(),
            'deadline' => now(), // Remplacez par la date de fin appropriée
        ]);

        return redirect()->route('tasks.index');
    }

    public function completeTask(Task $task)
    {
        $task->update([
            'completed' => true,
        ]);

        return redirect()->route('tasks.index');
    }

    public function deleteTask(Task $task)
    {
        $task->delete();

        return redirect()->route('tasks.index');
    }

    public function edit(Task $task)
    {
        return view('tasks.edit', compact('task'));
    }

    public function update(Request $request, Task $task)
    {
        $task->update([
            'name' => $request->input('task_name'),
        ]);

        return redirect()->route('tasks.index')->with('success', 'Tâche mise à jour avec succès.');
    }

}



