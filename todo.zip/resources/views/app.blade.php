<!DOCTYPE html>
<html>
<head>
    <title>Ma Liste de Tâches</title>
    <!-- Ajoutez vos balises meta, liens CSS, scripts JS, etc. ici -->
</head>
<body>

<nav>
    <!-- Barre de navigation si vous en avez une -->
</nav>

<div class="container">
    @yield('content')
</div>

<footer>
    <!-- Pied de page si vous en avez un -->
</footer>

</body>
</html>
