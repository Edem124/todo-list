<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div style="display: flex; justify-content: center; align-items: center; min-height: 100vh;">
        <div style="width: 400px; padding: 20px; background-color: #fff; border-radius: 10px; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);">
            <h1 style="text-align: center; margin-bottom: 20px;">Modifier la tâche</h1>
            <form action="<?php echo e(route('tasks.update', $task)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div style="margin-bottom: 10px;">
                    <label for="task_name" style="font-weight: bold;">Nom de la tâche :</label><br>
                    <input type="text" id="task_name" name="task_name" value="<?php echo e($task->name); ?>" required style="width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 5px;">
                </div>
                <div style="text-align: center;">
                    <button type="submit" style="background-color: #4CAF50; color: white; border: none; border-radius: 5px; padding: 8px 15px; margin-right: 10px;">Mettre à jour</button>
                    <a href="<?php echo e(route('tasks.index')); ?>" style="color: #3498db; text-decoration: none;">Annuler</a>
                </div>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Edem\Laravel\todo-list\resources\views/tasks/edit.blade.php ENDPATH**/ ?>