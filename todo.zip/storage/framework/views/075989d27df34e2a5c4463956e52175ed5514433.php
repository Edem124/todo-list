<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div style="display: flex; gap: 20px;">
        <div style="flex: 1; padding: 20px; background-color: #f4f4f4; border-radius: 10px;">
            <h2>Ajouter une nouvelle tâche</h2>
            <form action="<?php echo e(route('tasks.add')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="text" name="task_name" placeholder="Nouvelle tâche" required style="width: 80%; padding: 8px; border: 1px solid #ccc; border-radius: 5px;">
                <button type="submit" style="padding: 8px 15px; background-color: #4CAF50; color: white; border: none; border-radius: 5px;">Ajouter</button>
            </form>
        </div>
        
        <div style="flex: 2; padding: 20px; background-color: #fff; border-radius: 10px; box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);">
            <h1 style="text-decoration: underline;">Liste de tâches</h1>
            <ul style="list-style: none; padding: 0;">
                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li style="margin-bottom: 20px; border-bottom: 1px solid #eee; padding-bottom: 10px;">
                        <strong>Nom :</strong> 
                        <span <?php if($task->completed): ?> style="text-decoration: line-through; color: #888;" <?php endif; ?>>
                            <?php echo e($task->name); ?>

                        </span><br>
                        <strong>Date de création :</strong> <?php echo e($task->created_at); ?><br>
                        
                        <?php if($task->completed): ?>
                            <strong>Date de fin :</strong> <?php echo e($task->deadline); ?><br>
                        <?php else: ?>
                            <form action="<?php echo e(route('tasks.complete', $task)); ?>" method="post" style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <button type="submit" style="background-color: #4CAF50; color: white; border: none; border-radius: 3px; padding: 5px 10px;">Marquer comme accompli</button>
                            </form>
                            <a href="<?php echo e(route('tasks.edit', $task)); ?>" style="color: #3498db; margin-left: 10px;">Modifier</a>
                        <?php endif; ?>
                        
                        <form action="<?php echo e(route('tasks.delete', $task)); ?>" method="post" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" style="background-color: #f44336; color: white; border: none; border-radius: 3px; padding: 5px 10px; margin-left: 10px;">Supprimer</button>
                        </form>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
    
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Edem\Laravel\todo-list\resources\views/tasks/index.blade.php ENDPATH**/ ?>